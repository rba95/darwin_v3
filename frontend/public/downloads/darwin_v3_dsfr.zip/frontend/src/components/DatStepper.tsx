import { useState } from "react";
import { useForm, FormProvider } from "react-hook-form";
import { downloadDat } from "../api/client";
import { 
  DatFormValues, 
  defaultDatFormValues,
  defaultActeur,
  defaultVM
} from "../types/dat";
import { 
  ChevronLeft, 
  ChevronRight, 
  FileDown, 
  Check,
  Info,
  FileText,
  Users,
  Layers,
  Server,
  Settings,
  RefreshCw,
  Link2,
  ClipboardList,
  CheckCircle
} from "lucide-react";

// Import des composants de table
import { ActorsTable } from "./features/ActorsTable";
import { VMTable } from "./features/VMTable";
import { BriquesTable } from "./features/BriquesTable";
import { EchangesTable } from "./features/EchangesTable";
import { TechnologiesTable } from "./features/TechnologiesTable";
import { DnsTable } from "./features/DnsTable";
import { DependancesTable } from "./features/DependancesTable";
import { DocumentsReferenceTable, GlossaireTable } from "./features/DocumentsTable";

// Définition des étapes
const STEPS = [
  { id: 1, name: "Introduction", icon: Info, description: "Informations générales" },
  { id: 2, name: "Acteurs", icon: Users, description: "Acteurs du système" },
  { id: 3, name: "Fonctionnel", icon: Layers, description: "Spécifications fonctionnelles" },
  { id: 4, name: "Technique", icon: Settings, description: "Architecture technique" },
  { id: 5, name: "Infrastructure", icon: Server, description: "Ressources et VMs" },
  { id: 6, name: "Cycle de vie", icon: RefreshCw, description: "Déploiement et supervision" },
  { id: 7, name: "Dépendances", icon: Link2, description: "Dépendances externes" },
  { id: 8, name: "Contraintes", icon: ClipboardList, description: "Contraintes et SLA" },
  { id: 9, name: "Validation", icon: CheckCircle, description: "Vérification et génération" },
];

export function DatStepper() {
  const [currentStep, setCurrentStep] = useState(1);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const methods = useForm<DatFormValues>({
    defaultValues: {
      ...defaultDatFormValues,
      acteurs: [{ ...defaultActeur }],
      vms: [{ ...defaultVM }],
    }
  });

  const { handleSubmit, watch } = methods;
  const formData = watch();

  const onSubmit = async (data: DatFormValues) => {
    setIsGenerating(true);
    setError(null);
    setSuccess(false);
    
    try {
      const blob = await downloadDat(data);
      const url = window.URL.createObjectURL(new Blob([blob]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `DAT_${data.titre_projet || 'document'}.docx`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      setSuccess(true);
    } catch (err: unknown) {
      console.error('Erreur génération:', err);
      if (err && typeof err === 'object' && 'response' in err) {
        const axiosErr = err as { response?: { status: number; data?: unknown } };
        if (axiosErr.response?.status === 422) {
          setError('Données invalides. Veuillez vérifier les champs obligatoires.');
        } else {
          setError(`Erreur serveur (${axiosErr.response?.status}). Veuillez réessayer.`);
        }
      } else {
        setError('Erreur réseau. Vérifiez votre connexion.');
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const nextStep = () => {
    if (currentStep < STEPS.length) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const goToStep = (step: number) => {
    setCurrentStep(step);
  };

  // Calcul du pourcentage de completion
  const completionPercentage = Math.round(((currentStep - 1) / (STEPS.length - 1)) * 100);

  return (
    <div className="min-h-screen bg-[#F6F6F6]">
      {/* Header DSFR */}
      <header className="bg-white border-b-4 border-[#000091] shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-[#000091] rounded flex items-center justify-center">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-[#161616]">
                  Dossier d'Architecture Technique
                </h1>
                <p className="text-sm text-[#666666]">
                  {formData.titre_projet || "Nouveau projet"}
                </p>
              </div>
            </div>
            
            {/* Progress indicator */}
            <div className="hidden md:flex items-center gap-2 text-sm">
              <span className="text-[#666666]">Progression :</span>
              <div className="w-32 h-2 bg-[#EEEEEE] rounded-full overflow-hidden">
                <div 
                  className="h-full bg-[#000091] transition-all duration-300"
                  style={{ width: `${completionPercentage}%` }}
                />
              </div>
              <span className="font-semibold text-[#000091]">{completionPercentage}%</span>
            </div>
          </div>
        </div>
      </header>

      {/* Stepper Navigation */}
      <nav className="bg-white border-b border-gray-200 shadow-sm overflow-x-auto">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-center gap-1 py-2 min-w-max">
            {STEPS.map((step, index) => {
              const Icon = step.icon;
              const isActive = currentStep === step.id;
              const isCompleted = currentStep > step.id;
              
              return (
                <div key={step.id} className="flex items-center">
                  <button
                    type="button"
                    onClick={() => goToStep(step.id)}
                    className={`
                      flex items-center gap-2 px-3 py-2 rounded transition-all
                      ${isActive 
                        ? 'bg-[#000091] text-white' 
                        : isCompleted 
                          ? 'bg-[#B8FEC9] text-[#18753C] hover:bg-[#a0e5b5]' 
                          : 'bg-[#F6F6F6] text-[#666666] hover:bg-[#EEEEEE]'
                      }
                    `}
                  >
                    <div className={`
                      w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold
                      ${isActive 
                        ? 'bg-white text-[#000091]' 
                        : isCompleted 
                          ? 'bg-[#18753C] text-white' 
                          : 'bg-[#CECECE] text-white'
                      }
                    `}>
                      {isCompleted ? <Check className="w-3 h-3" /> : step.id}
                    </div>
                    <span className="hidden lg:inline text-sm font-medium">{step.name}</span>
                    <Icon className="w-4 h-4 lg:hidden" />
                  </button>
                  
                  {index < STEPS.length - 1 && (
                    <div className={`
                      w-4 h-0.5 mx-1
                      ${isCompleted ? 'bg-[#18753C]' : 'bg-[#CECECE]'}
                    `} />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-6">
        <FormProvider {...methods}>
          <form onSubmit={handleSubmit(onSubmit)}>
            
            {/* Step Content Card */}
            <div className="bg-white border border-gray-200 shadow-sm">
              {/* Step Header */}
              <div className="px-6 py-4 border-b border-gray-200 bg-[#F6F6F6]">
                <div className="flex items-center gap-3">
                  {(() => {
                    const StepIcon = STEPS[currentStep - 1]?.icon || Info;
                    return (
                      <div className="w-10 h-10 rounded-lg bg-[#000091] flex items-center justify-center">
                        <StepIcon className="w-5 h-5 text-white" />
                      </div>
                    );
                  })()}
                  <div>
                    <h2 className="text-xl font-bold text-[#161616]">
                      {STEPS[currentStep - 1]?.name}
                    </h2>
                    <p className="text-sm text-[#666666]">
                      {STEPS[currentStep - 1]?.description}
                    </p>
                  </div>
                </div>
              </div>

              {/* Step Content */}
              <div className="p-6">
                {renderStepContent(currentStep, methods)}
              </div>
            </div>

            {/* Error / Success Messages */}
            {error && (
              <div className="mt-4 p-4 bg-[#FFE9E9] border-l-4 border-[#CE0500] text-[#161616]">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-[#CE0500]">Erreur :</span>
                  <span>{error}</span>
                </div>
              </div>
            )}
            
            {success && (
              <div className="mt-4 p-4 bg-[#B8FEC9] border-l-4 border-[#18753C] text-[#161616]">
                <div className="flex items-center gap-2">
                  <Check className="w-5 h-5 text-[#18753C]" />
                  <span className="font-semibold">Document généré avec succès !</span>
                </div>
              </div>
            )}

            {/* Navigation Footer */}
            <div className="mt-6 flex items-center justify-between">
              <button
                type="button"
                onClick={prevStep}
                disabled={currentStep === 1}
                className={`
                  inline-flex items-center gap-2 px-6 py-3 font-medium transition-colors
                  ${currentStep === 1 
                    ? 'bg-[#EEEEEE] text-[#929292] cursor-not-allowed' 
                    : 'bg-white text-[#000091] border-2 border-[#000091] hover:bg-[#F6F6F6]'
                  }
                `}
              >
                <ChevronLeft className="w-5 h-5" />
                Précédent
              </button>

              <div className="flex items-center gap-2 text-sm text-[#666666]">
                Étape {currentStep} sur {STEPS.length}
              </div>

              {currentStep < STEPS.length ? (
                <button
                  type="button"
                  onClick={nextStep}
                  className="inline-flex items-center gap-2 px-6 py-3 bg-[#000091] text-white font-medium hover:bg-[#1212FF] transition-colors"
                >
                  Suivant
                  <ChevronRight className="w-5 h-5" />
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={isGenerating}
                  className={`
                    inline-flex items-center gap-2 px-8 py-3 font-medium transition-colors
                    ${isGenerating 
                      ? 'bg-[#666666] text-white cursor-wait' 
                      : 'bg-[#18753C] text-white hover:bg-[#146333]'
                    }
                  `}
                >
                  {isGenerating ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Génération...
                    </>
                  ) : (
                    <>
                      <FileDown className="w-5 h-5" />
                      Générer le DAT
                    </>
                  )}
                </button>
              )}
            </div>
          </form>
        </FormProvider>
      </main>

      {/* Footer */}
      <footer className="mt-8 py-4 border-t border-gray-200 bg-white">
        <div className="max-w-6xl mx-auto px-4 text-center text-sm text-[#666666]">
          Système de Design de l'État Français • DAT Generator v2.0
        </div>
      </footer>
    </div>
  );
}

// Rendu du contenu de chaque étape
function renderStepContent(step: number, methods: ReturnType<typeof useForm<DatFormValues>>) {
  const { register, watch } = methods;

  switch (step) {
    case 1: // Introduction
      return (
        <div className="space-y-8">
          {/* Informations générales */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-[#161616]">
                Titre du projet <span className="text-[#CE0500]">*</span>
              </label>
              <input
                {...register("titre_projet")}
                placeholder="Ex: Application de gestion RH"
                className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] placeholder-[#666666] focus:border-[#000091] focus:bg-white focus:outline-none transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-medium text-[#161616]">
                Date du document
              </label>
              <input
                type="date"
                {...register("date")}
                className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] focus:border-[#000091] focus:bg-white focus:outline-none transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-medium text-[#161616]">
                Chef de projet <span className="text-[#CE0500]">*</span>
              </label>
              <input
                {...register("chef_projet")}
                placeholder="Nom du chef de projet"
                className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] placeholder-[#666666] focus:border-[#000091] focus:bg-white focus:outline-none transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-medium text-[#161616]">
                Contact technique
              </label>
              <input
                {...register("contact_tech")}
                placeholder="Email ou téléphone"
                className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] placeholder-[#666666] focus:border-[#000091] focus:bg-white focus:outline-none transition-colors"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-[#161616]">
              Objet du document
            </label>
            <textarea
              {...register("objet_document")}
              rows={4}
              placeholder="Décrivez l'objet et le périmètre de ce document d'architecture technique..."
              className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] placeholder-[#666666] focus:border-[#000091] focus:bg-white focus:outline-none resize-none transition-colors"
            />
          </div>

          {/* Documents de référence & Glossaire */}
          <div className="space-y-6 pt-4 border-t border-gray-200">
            <DocumentsReferenceTable />
            <GlossaireTable />
          </div>
        </div>
      );

    case 2: // Acteurs
      return <ActorsTable />;

    case 3: // Fonctionnel
      return (
        <div className="space-y-8">
          {/* Schéma fonctionnel */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                {...register("has_schema")}
                id="has_schema"
                className="w-5 h-5 accent-[#000091]"
              />
              <label htmlFor="has_schema" className="text-sm font-medium text-[#161616]">
                Inclure un schéma fonctionnel
              </label>
            </div>
            
            {watch("has_schema") && (
              <div className="p-4 bg-[#E8EDFF] border-l-4 border-[#0063CB]">
                <p className="text-sm text-[#161616]">
                  Les images de schémas doivent être ajoutées manuellement dans le document Word après génération.
                </p>
              </div>
            )}

            <div className="space-y-2">
              <label className="block text-sm font-medium text-[#161616]">
                Description fonctionnelle
              </label>
              <textarea
                {...register("schema_description")}
                rows={4}
                placeholder="Décrivez le fonctionnement global de l'application, les flux principaux..."
                className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] placeholder-[#666666] focus:border-[#000091] focus:bg-white focus:outline-none resize-none transition-colors"
              />
            </div>
          </div>

          {/* Briques fonctionnelles */}
          <BriquesTable />

          {/* Échanges de données */}
          <EchangesTable />
        </div>
      );

    case 4: // Technique
      return (
        <div className="space-y-8">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-[#161616]">
              Description de l'architecture
            </label>
            <textarea
              {...register("description_architecture")}
              rows={5}
              placeholder="Décrivez l'architecture technique de l'application (tiers, composants, interactions)..."
              className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] placeholder-[#666666] focus:border-[#000091] focus:bg-white focus:outline-none resize-none transition-colors"
            />
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-[#161616]">
                Authentification
              </label>
              <textarea
                {...register("description_authentification")}
                rows={3}
                placeholder="Mécanismes d'authentification utilisés..."
                className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] placeholder-[#666666] focus:border-[#000091] focus:bg-white focus:outline-none resize-none transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-medium text-[#161616]">
                Administration technique
              </label>
              <textarea
                {...register("description_administrationtechnique")}
                rows={3}
                placeholder="Gestion des droits, accès techniques..."
                className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] placeholder-[#666666] focus:border-[#000091] focus:bg-white focus:outline-none resize-none transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-medium text-[#161616]">
                Administration fonctionnelle
              </label>
              <textarea
                {...register("description_adminfonctionnelle")}
                rows={3}
                placeholder="Gestion des droits utilisateurs, habilitations..."
                className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] placeholder-[#666666] focus:border-[#000091] focus:bg-white focus:outline-none resize-none transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-medium text-[#161616]">
                Administration inter-applicative
              </label>
              <textarea
                {...register("description_interapplicative")}
                rows={3}
                placeholder="Échanges et interactions entre applications..."
                className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] placeholder-[#666666] focus:border-[#000091] focus:bg-white focus:outline-none resize-none transition-colors"
              />
            </div>
          </div>

          {/* Choix technologiques */}
          <TechnologiesTable />

          {/* Segmentation */}
          <div className="p-4 bg-[#F6F6F6] border border-gray-200">
            <label className="block text-sm font-medium text-[#161616] mb-2">
              Données sensibles / DR
            </label>
            <select
              {...register("segmentation_dr")}
              className="w-full md:w-auto px-4 py-3 border-b-2 border-[#3A3A3A] bg-white text-[#161616] focus:border-[#000091] focus:outline-none"
            >
              <option value="Non">Non - Pas de données sensibles</option>
              <option value="Oui">Oui - Données DR ou sensibles</option>
            </select>
          </div>

          {/* DNS */}
          <DnsTable />
        </div>
      );

    case 5: // Infrastructure
      return <VMTable />;

    case 6: // Cycle de vie
      return (
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-[#161616]">
              Déploiement
            </label>
            <textarea
              {...register("deploiement")}
              rows={4}
              placeholder="Décrivez la stratégie de déploiement (CI/CD, environnements, processus)..."
              className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] placeholder-[#666666] focus:border-[#000091] focus:bg-white focus:outline-none resize-none transition-colors"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-[#161616]">
              Migration / Reprise de données
            </label>
            <textarea
              {...register("migration_reprise")}
              rows={4}
              placeholder="Plan de migration des données existantes, stratégie de reprise..."
              className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] placeholder-[#666666] focus:border-[#000091] focus:bg-white focus:outline-none resize-none transition-colors"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-[#161616]">
              Supervision et observabilité
            </label>
            <textarea
              {...register("supervision")}
              rows={4}
              placeholder="Outils de monitoring, alerting, métriques collectées..."
              className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] placeholder-[#666666] focus:border-[#000091] focus:bg-white focus:outline-none resize-none transition-colors"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-[#161616]">
              Sauvegardes et restauration
            </label>
            <textarea
              {...register("sauvegarde_restauration")}
              rows={4}
              placeholder="Politique de backup, rétention, procédure de restauration..."
              className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] placeholder-[#666666] focus:border-[#000091] focus:bg-white focus:outline-none resize-none transition-colors"
            />
          </div>
        </div>
      );

    case 7: // Dépendances
      return <DependancesTable />;

    case 8: // Contraintes
      return (
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-[#161616]">
              Contraintes spécifiques
            </label>
            <textarea
              {...register("contraintes")}
              rows={5}
              placeholder="Contraintes techniques, réglementaires, organisationnelles à prendre en compte..."
              className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] placeholder-[#666666] focus:border-[#000091] focus:bg-white focus:outline-none resize-none transition-colors"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-[#161616]">
              Niveau de service attendu (SLA)
            </label>
            <textarea
              {...register("niveau_services")}
              rows={5}
              placeholder="Disponibilité attendue, temps de réponse, GTR/GTI..."
              className="w-full px-4 py-3 border-b-2 border-[#3A3A3A] bg-[#F6F6F6] text-[#161616] placeholder-[#666666] focus:border-[#000091] focus:bg-white focus:outline-none resize-none transition-colors"
            />
          </div>
        </div>
      );

    case 9: // Validation
      return (
        <div className="space-y-6">
          {/* Résumé du document */}
          <div className="p-6 bg-[#E8EDFF] border-l-4 border-[#0063CB]">
            <h3 className="text-lg font-semibold text-[#161616] mb-4">Résumé du document</h3>
            <div className="grid md:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-[#666666]">Projet :</span>
                <span className="ml-2 font-medium">{watch("titre_projet") || "Non renseigné"}</span>
              </div>
              <div>
                <span className="text-[#666666]">Chef de projet :</span>
                <span className="ml-2 font-medium">{watch("chef_projet") || "Non renseigné"}</span>
              </div>
              <div>
                <span className="text-[#666666]">Acteurs définis :</span>
                <span className="ml-2 font-medium">{watch("acteurs")?.length || 0}</span>
              </div>
              <div>
                <span className="text-[#666666]">VMs définies :</span>
                <span className="ml-2 font-medium">{watch("vms")?.length || 0}</span>
              </div>
              <div>
                <span className="text-[#666666]">Briques fonctionnelles :</span>
                <span className="ml-2 font-medium">{watch("briques_fonctionnelles")?.length || 0}</span>
              </div>
              <div>
                <span className="text-[#666666]">Technologies :</span>
                <span className="ml-2 font-medium">{watch("choix_technologiques")?.length || 0}</span>
              </div>
            </div>
          </div>

          {/* Instructions */}
          <div className="p-4 bg-[#F6F6F6] border border-gray-200">
            <h4 className="font-semibold text-[#161616] mb-2">Avant de générer :</h4>
            <ul className="list-disc list-inside space-y-1 text-sm text-[#666666]">
              <li>Vérifiez que toutes les informations obligatoires sont remplies</li>
              <li>Les champs vides apparaîtront comme "Non renseigné" dans le document</li>
              <li>Vous pourrez compléter le document Word après génération</li>
              <li>Les schémas et images doivent être ajoutés manuellement</li>
            </ul>
          </div>

          {/* Call to action */}
          <div className="text-center py-6">
            <p className="text-lg text-[#161616] mb-4">
              Prêt à générer votre Dossier d'Architecture Technique ?
            </p>
            <p className="text-sm text-[#666666]">
              Cliquez sur le bouton "Générer le DAT" ci-dessous pour télécharger votre document Word.
            </p>
          </div>
        </div>
      );

    default:
      return null;
  }
}

export default DatStepper;
