import DatStepper from "./components/DatStepper";

function App() {
  return <DatStepper />;
}

export default App;
