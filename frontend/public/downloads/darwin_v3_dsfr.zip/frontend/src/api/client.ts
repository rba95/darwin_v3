import axios from 'axios';

// Détection automatique de l'environnement
const getBaseUrl = () => {
  // Si on est sur un sandbox (URL contient .sandbox.)
  if (window.location.hostname.includes('.sandbox.')) {
    // Remplacer le port frontend (5173) par le port backend (8000)
    return window.location.origin.replace('5173', '8000') + '/api/v1';
  }
  // Sinon, localhost en développement
  return 'http://localhost:8000/api/v1';
};

const api = axios.create({
  baseURL: getBaseUrl(),
});

export async function downloadDat(data: unknown) {
  const response = await api.post('/generate', data, {
    responseType: 'blob',
  });
  return response.data;
}

export default api;
